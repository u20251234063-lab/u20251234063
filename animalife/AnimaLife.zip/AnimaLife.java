
package animalife;
public class AnimaLife {
    public static void main(String[] args) {
        
    }
    
}
