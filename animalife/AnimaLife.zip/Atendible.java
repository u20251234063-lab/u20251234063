
package animalife;
public interface Atendible {
    void atenderMascota(Mascota m);
    void registrarObservaciones(String obs);
}
